﻿$(function(){
 
	resize();
	$(window).resize(function(event) {
		resize();
	});


	$(".ul_tag li").click(function () {
	    $(this).addClass("on").siblings().removeClass("on");
	  
	})

	$(".banner").each(function () {
	    if ($(this).find(".item").length > 1) {
	        var owl = $(this).owlCarousel({ items: 1, dots: false, nav: true, navText: ["<img src='skin/images/cur1.png' />", "<img src='skin/images/cur2.png' />"], loop: true, autoplay: true });
	        owl.on('changed.owl.carousel', function (event) {
	            owl.find(".animated").each(function () { $(this).removeClass($(this).attr("data-animation")); })
	            owl.find(".owl-item").eq(event.item.index).find(".animated").each(function () { $(this).addClass($(this).attr("data-animation")); });
	        })
	    }
	})
	$(".banner .owl-item").eq(2).find(".animated").each(function () {
	    $(this).addClass($(this).attr("data-animation"));
	})
	$(window).scroll(function () {
	    $(".animated").each(function () {
	        if ($(this).offset().top - $(window).scrollTop() > $(window).height() - 80)
	            $(this).removeClass($(this).attr("data-animation"));
	        else
	            $(this).addClass($(this).attr("data-animation"));
	    })
	    if ($(window).scrollTop() > 30) {
	        $(".header").addClass("fixed");
	    }
	    else { $(".header").removeClass("fixed"); }
	})

	var page2_owl = $(".page2_owl .owl").owlCarousel({
	    items: 4,  responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:3
	        },
	        1000:{
	            items:4
	        }
	    },
	    margin: 10, loop: true
	});
	$(".page2_owl .prev").click(function () {
	    page2_owl.trigger("prev.owl.carousel");
	});
	$(".page2_owl .next").click(function () {
	    page2_owl.trigger("next.owl.carousel");
	});
	var team_owl = $(".team_owl .owl").owlCarousel({
	    items: 6,
	    responsive:{
	        0:{
	            items:2
	        },
	        600:{
	            items:4
	        },
	        1000:{
	            items:6
	        }
	    },
	    dots: false, margin: 10, loop: true
	});
	$(".team_owl .prev").click(function () {
	    team_owl.trigger("prev.owl.carousel");
	});
	$(".team_owl .next").click(function () {
	    team_owl.trigger("next.owl.carousel");
	});

	var news_owl = $(".news_owl .owl").owlCarousel({
	    items: 3,  responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:3
	        }
	    },
	    dots: false, margin: 10, loop: true
	});
	$(".news_owl .prev").click(function () {
	    news_owl.trigger("prev.owl.carousel");
	});
	$(".news_owl .next").click(function () {
	    news_owl.trigger("next.owl.carousel");
	});
	$(".menu_btn").click(function () { $(".header").toggleClass("h_menu") });

	$(".wow_list .wow").each(function (e) {
	    $(this).attr("data-wow-delay", ($(this).index() / 10) + "s");
	})
	$(window).load(function () {
	    if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))) {
	        new WOW().init();
	    }
	})

	$('.btn_def').click(function () {
	    $('.modal').fadeIn();
	});
	$(".team_owl .item").click(function () {
	    $(".team_owl .item").removeClass("on");
	    $(this).addClass("on");
	});
	$(".page2_owl .item").click(function () {
	    $(".page2_owl .item").removeClass("on");
	    $(this).addClass("on");
	});

});

/*main*/
//

function font() {


}


/*call*/
//
function resize(){
    var ht = $(window).height();
    $(".mainer").css("min-height", ht + "px");
	 
} 